#!/bin/sh
# squ=$(ps aux | grep 'squeezelite' | awk '{print $2}')
# echo $squ
# kill $squ
killall -e squeezelite