# LoxBerry-Plugin-squeezelite
This is a LoxBerry Plugin for Squeezelite, a Logitech Media Server Player.

About this plugin: http://www.loxwiki.eu/display/LOXBERRY/Squeezelite+Player
About LoxBerry http://www.loxwiki.eu/display/LOXBERRY/LoxBerry 

This project is in development. Please use the issue tracker for bugs and feature requests.

## Roadmap
### Shorthand
* Running Alpha and Beta releases
* First Release

### Possible later improvements
* Recognize and save player name changes by the server
* Support of custom Squeezelite runtimes (newer versions, possibly compile own executable)

### Possible Long Term Evolution
* LMS Proxy to feed Loxone with status information (volume...)
